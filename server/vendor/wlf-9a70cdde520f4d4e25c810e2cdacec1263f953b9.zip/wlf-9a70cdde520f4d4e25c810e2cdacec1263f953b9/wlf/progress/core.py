# -*- coding=UTF-8 -*-
"""Progress core.  """

from __future__ import (absolute_import, division, print_function,
                        unicode_literals)

from .handlers.base import BaseProgressHandler

DefaultHandler = BaseProgressHandler
