# -*- coding=UTF-8 -*-
"""All used exceptions.  """


class DatabaseError(ValueError):
    """Indicate can not determinate database.  """
