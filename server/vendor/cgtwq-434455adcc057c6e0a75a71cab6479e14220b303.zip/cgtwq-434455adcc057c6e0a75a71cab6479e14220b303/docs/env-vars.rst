环境变量
-----------------------

CGTEAMWORK_URL

  默认值: ``http://192.168.55.11``。

  CGTeamWork 服务器地址。

CGTEAMWORK_DEFAULT_TOKEN

  CGTeamWork 默认用户令牌。

CGTEAMWORK_DESKTOP_WEBSOCKET_URL

  默认值: ``ws://127.0.0.1:64999``

  CGTeamWork 桌面端 WebSocket 地址。

CGTEAMWORK_CONNECTION_TIMEOUT

  默认值: ``1``

  CGTeamWork WebSocket 连接超时秒数。

CGTEAMWORK_MIN_FETCH_INTERVAL

  默认值: ``1``

  CGTeamWork 插件数据缓存有效秒数。

CGTWQ_TEST_ACCOUNT

  运行测试时使用的账号，如果未提供则尝试使用当前运行桌面客户端帐号。

CGTWQ_TEST_PASSWORD

  运行测试时使用的密码，如果未提供则尝试使用当前运行桌面客户端帐号。
