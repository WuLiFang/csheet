# Changelog

All notable changes to this project will be documented in this file. See [standard-version](https://github.com/conventional-changelog/standard-version) for commit guidelines.

## 3.0.0-beta.0 (2019-06-28)

### Features

- add `EmptySelection` exception. ([2d91ed6](https://github.com/WuLiFang/cgtwq/commit/2d91ed6))

### Tests

- fix broken test ([f60fabf](https://github.com/WuLiFang/cgtwq/commit/f60fabf))

## 3.0.0-alpha.8 (2019-01-11)

## 3.0.0-alpha.7 (2018-12-15)

## 3.0.0-alpha.6 (2018-11-15)

## 3.0.0-alpha.5 (2018-11-06)

## 3.0.0-alpha.4 (2018-09-28)

## 3.0.0-alpha.3 (2018-09-27)

## 3.0.0-alpha.2 (2018-09-27)

## 3.0.0-alpha.1 (2018-09-27)

## 3.0.0-alpha.0 (2018-09-26)

## 2.5.0 (2018-08-31)

### 2.4.2 (2018-08-13)

### 2.4.1 (2018-08-07)

## 2.4.0 (2018-08-07)

## 2.3.0 (2018-07-27)

### 2.2.1 (2018-07-23)

## 2.2.0 (2018-07-23)

### 2.1.1 (2018-07-23)

## 2.1.0 (2018-07-23)

### 2.0.1 (2018-07-20)

## 2.0.0 (2018-07-20)

## 1.4.0 (2018-06-25)

### 1.3.2 (2018-05-22)

### 1.3.1 (2018-05-21)

## 1.3.0 (2018-05-21)

### 1.2.1 (2018-04-13)

## 1.2.0 (2018-04-10)

## 1.1.0 (2018-03-30)

### 1.0.3 (2018-03-30)

### 1.0.2 (2018-03-28)

### 1.0.1 (2018-03-28)

## 1.0.0 (2018-03-28)
